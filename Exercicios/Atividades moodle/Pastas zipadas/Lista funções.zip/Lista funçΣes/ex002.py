# PROGRAMA FUNÇÃO DOBRA
def dobra(num):
    d = num*2
    return f"O dobro de {num} é {d}"


n = int(input("insira um valor: "))
print(dobra(n))
