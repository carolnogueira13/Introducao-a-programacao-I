# PROGRAMA PARA LER 2 NÚMEROS E O QUADRADO DA DIFERENÇA DO PRIMEIRO PELO SEGUNDO
num1 = int(input("Insira o primeiro número: "))
num2 = int(input("Insira o segundo número: "))
resultado = (num1 - num2) ** 2
print(f"O quadrado da diferença de {num1} por {num2} é {resultado}.")
